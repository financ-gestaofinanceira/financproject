import { useCallback, useContext, useEffect, useState } from "react";
import { ContaContext } from "../../../contexts/ContaContext";
import TitleText from "../../../props/TitleText/TitleText";
import InputSelect from "../../../props/InputSelect/InputSelect";
import InputDate from "../../../props/InputDate/InputDate";
import CheckBoxList from "../../../props/CheckBoxList/CheckBoxList";
import InputText from "../../../props/InputText/InputText";
import InputPrice from "../../../props/InputPrice/InputPrice";
import { Categoria } from "../../../models/Movimentacoes/GetMovimentacoes";
import { CategoriaResponse } from "../../../models/Categorias/Categorias";
import api from "../../../services/api/apiConnect";

type Props = {};

const diasSemana = [
  { id: 0, nome: "Domingo" },
  { id: 1, nome: "Segunda-feira" },
  { id: 2, nome: "Terça-feira" },
  { id: 3, nome: "Quarta-feira" },
  { id: 4, nome: "Quinta-feira" },
  { id: 5, nome: "Sexta-feira" },
  { id: 6, nome: "Sábado" },
];

const meses = [
  { label: "Janeiro", value: "1" },
  { label: "Fevereiro", value: "2" },
  { label: "Março", value: "3" },
  { label: "Abril", value: "4" },
  { label: "Maio", value: "5" },
  { label: "Junho", value: "6" },
  { label: "Julho", value: "7" },
  { label: "Agosto", value: "8" },
  { label: "Setembro", value: "9" },
  { label: "Outubro", value: "10" },
  { label: "Novembro", value: "11" },
  { label: "Dezembro", value: "12" },
];

const diasPorMes: Record<string, number> = {
  "1": 31,
  "2": 28,
  "3": 31,
  "4": 30,
  "5": 31,
  "6": 30,
  "7": 31,
  "8": 31,
  "9": 30,
  "10": 31,
  "11": 30,
  "12": 31,
};

const MovimentacaoFixa: React.FC<Props> = () => {
  const getNow = (isEnd: boolean = false) => {
    const now = new Date();
    let date: Date;

    if (!isEnd) {
      date = new Date(now.getFullYear(), now.getMonth(), 1);
      date.setHours(0, 0, 0, 0);
    } else {
      date = new Date(now.getFullYear(), now.getMonth() + 1, 0);
      date.setHours(23, 59, 59, 999);
    }

    const pad = (n: number) => String(n).padStart(2, "0");

    return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(
      date.getDate(),
    )}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
  };

  const { conta } = useContext(ContaContext);

  const [dataInicial, setDataInicial] = useState(getNow(false));
  const [dataFinal, setDataFinal] = useState(getNow(true));

  const [ocorrencia, setOcorrencia] = useState("1");
  const [mes, setMes] = useState("1");
  const [dia, setDia] = useState("1");
  const [diasSemanaSelecionados, setDiasSemanaSelecionados] = useState<
    number[]
  >([1]);

  const [tipo, setTipo] = useState<string>("receita");

  const dias = Array.from({ length: diasPorMes[mes] }, (_, i) => ({
    label: String(i + 1),
    value: String(i + 1),
  }));

  const [categorias, setCategorias] = useState<CategoriaResponse>();

  const [categoriasSelecionadas, setCategoriasSelecionadas] = useState<
    number[]
  >([]);

  const buscaCategorias = useCallback(async () => {
    try {
      const resposta = await api<CategoriaResponse>(
        `/Contas/${conta!.idConta}/Categorias`,
        "GET",
        undefined,
      );
      if (resposta.sucesso && resposta.dados) {
        setCategorias(resposta.dados);
      }
    } catch (error) {
      console.error("Erro ao buscar categorias:", error);
    }
  }, [conta!.idConta]);

  useEffect(() => {
    const maxDias = diasPorMes[mes];
    buscaCategorias();

    if (Number(dia) > maxDias) {
      setDia(String(maxDias));
    }
  }, [buscaCategorias, mes]);

  console.log(diasSemanaSelecionados);
  return (
    <div>
      <TitleText text={`Movimentações Fixas - ${conta!.titulo}`} />

      <InputSelect
        label="Tipo de Ocorrência"
        opcoes={[
          { label: "Semanal", value: "0" },
          { label: "Mensal", value: "1" },
          { label: "Anual", value: "2" },
        ]}
        value={ocorrencia}
        onChange={setOcorrencia}
      />

      <InputDate
        label="Data Inicial"
        text={dataInicial}
        setText={setDataInicial}
      />

      <InputDate label="Data Final" text={dataFinal} setText={setDataFinal} />

      {ocorrencia === "0" && (
        <CheckBoxList
          itens={diasSemana}
          idKey="id"
          labelKey="nome"
          selecionados={diasSemanaSelecionados}
          onChange={setDiasSemanaSelecionados}
          label="Dias da Semana"
        />
      )}

      {ocorrencia === "1" && (
        <InputSelect label="Dia" opcoes={dias} value={dia} onChange={setDia} />
      )}

      {ocorrencia === "2" && (
        <>
          <InputSelect
            label="Mês"
            opcoes={meses}
            value={mes}
            onChange={setMes}
          />

          <InputSelect
            label="Dia"
            opcoes={dias}
            value={dia}
            onChange={setDia}
          />
        </>
      )}

      <div className="fnc-transaction-type">
        <button
          type="button"
          className={`type-btn ${tipo === "receita" ? "active" : ""}`}
          data-type="receita"
          onClick={() => setTipo("receita")}
        >
          Receita
        </button>

        <button
          type="button"
          className={`type-btn ${tipo === "despesa" ? "active" : ""}`}
          data-type="despesa"
          onClick={() => setTipo("despesa")}
        >
          Despesa
        </button>
      </div>

      <InputText
        label="Título"
        text=""
        setText={() => null}
        placeholder="Ex: Salário"
      />

      <InputPrice
        label="Valor"
        formattedValue=""
        setFormattedValue={() => null}
        setValue={() => null}
      />
      <InputText label="Observação" text="" setText={() => null} />

      <CheckBoxList<Categoria>
        itens={[...(categorias?.conteudo ?? [])]}
        idKey="idCategoria"
        labelKey="nome"
        selecionados={categoriasSelecionadas}
        onChange={setCategoriasSelecionadas}
        label="Categorias"
      />
    </div>
  );
};

export default MovimentacaoFixa;
