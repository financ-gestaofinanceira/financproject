import React, { useState } from "react";
import InputText from "../../props/InputText/InputText";
import { TypeText } from "../../props/InputText/TypeText";
import FncButton from "../../props/FncButton/FncButton";

const OpcoesUsuario: React.FC = () => {
  const [erroMsg, setErroMsg] = useState<string | undefined>(undefined);
  const [primeiroNome, setPrimeiroNome] = useState<string>("");
  const [segundoNome, setSegundoNome] = useState<string>("");
  const [email, setEmail] = useState<string>("");
  const [senha, setSenha] = useState<string>("");
  const [confirmaSenha, setConfirmaSenha] = useState<string>("");

  return (
    <div>
      <InputText
        label="Senha antiga"
        text=""
        type={TypeText.Password}
        setText={() => null}
      />
      <InputText
        label="Nova senha"
        text=""
        type={TypeText.Password}
        setText={() => null}
      />
      <FncButton title="Alterar senha" onClick={() => null}/>
    </div>
  );
};

export default OpcoesUsuario;
