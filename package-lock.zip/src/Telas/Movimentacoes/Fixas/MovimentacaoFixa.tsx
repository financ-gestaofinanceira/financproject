import { useCallback, useContext, useEffect, useState } from "react";
import { ContaContext } from "../../../contexts/ContaContext";
import { MovimentacaoContext } from "../../../contexts/MovimentacaoContext";
import TitleText from "../../../props/TitleText/TitleText";
import InputSelect from "../../../props/InputSelect/InputSelect";
import InputDate from "../../../props/InputDate/InputDate";
import CheckBoxList from "../../../props/CheckBoxList/CheckBoxList";
import InputText from "../../../props/InputText/InputText";
import InputPrice from "../../../props/InputPrice/InputPrice";
import FncTable from "../../../props/FncTable/FncTable";
import CadContasModal from "../../../componentes/Modal/Modal";
import CadMov from "../CadMov/CadMov";
import {
  Categoria,
  Movimentacao,
} from "../../../models/Movimentacoes/GetMovimentacoes";
import { CategoriaResponse } from "../../../models/Categorias/Categorias";
import api from "../../../services/api/apiConnect";
import "./MovimentacaoFixa.css";
import FncButton from "../../../props/FncButton/FncButton";
import { ApiResult } from "../../../models/interface/ApiResult";
import { data } from "react-router-dom";

type Props = {};

// ── tipos para fixas ────────────────────────────────────────────────────────

export type MovimentacaoFixaItem = {
  id: number;
  tipo: number;
  dataInicio: string;
  dataFim: string;
  dataOcorrencia: string;
  ocorrenciaDiaria: any[];
  expirado: boolean;
  movimentacaoBase: import("../../../models/Movimentacoes/GetMovimentacoes").Movimentacao;
};

// ── constantes ───────────────────────────────────────────────────────────────

const diasSemana = [
  { id: 0, nome: "Domingo" },
  { id: 1, nome: "Segunda-feira" },
  { id: 2, nome: "Terça-feira" },
  { id: 3, nome: "Quarta-feira" },
  { id: 4, nome: "Quinta-feira" },
  { id: 5, nome: "Sexta-feira" },
  { id: 6, nome: "Sábado" },
];

const meses = [
  { label: "Janeiro", value: "1" },
  { label: "Fevereiro", value: "2" },
  { label: "Março", value: "3" },
  { label: "Abril", value: "4" },
  { label: "Maio", value: "5" },
  { label: "Junho", value: "6" },
  { label: "Julho", value: "7" },
  { label: "Agosto", value: "8" },
  { label: "Setembro", value: "9" },
  { label: "Outubro", value: "10" },
  { label: "Novembro", value: "11" },
  { label: "Dezembro", value: "12" },
];

const diasPorMes: Record<string, number> = {
  "1": 31,
  "2": 28,
  "3": 31,
  "4": 30,
  "5": 31,
  "6": 30,
  "7": 31,
  "8": 31,
  "9": 30,
  "10": 31,
  "11": 30,
  "12": 31,
};

const tipoOcorrenciaLabel: Record<number, string> = {
  0: "Semanal",
  1: "Mensal",
  2: "Anual",
};

// ── helpers ──────────────────────────────────────────────────────────────────
const toUtc3 = (iso: string) =>
  new Date(new Date(iso).getTime() - 3 * 60 * 60 * 1000);

const formatDate = (iso: string) => {
  if (!iso) return "-";

  const data = toUtc3(iso);

  const dia = String(data.getDate()).padStart(2, "0");
  const mes = String(data.getMonth() + 1).padStart(2, "0");
  const ano = data.getFullYear();

  return `${dia}/${mes}/${ano}`;
};

const formatDateAnual = (iso: string) => {
  if (!iso) return "-";

  const data = toUtc3(iso);

  const dia = String(data.getDate()).padStart(2, "0");
  const mes = String(data.getMonth() + 1).padStart(2, "0");

  return `${dia}/${mes}`;
};

const formatDatemes = (iso: string) => {
  if (!iso) return "-";

  const data = toUtc3(iso);

  return `Dia ${data.getDate()}`;
};
// ── componente ───────────────────────────────────────────────────────────────

const MovimentacaoFixa: React.FC<Props> = () => {
  const getNow = (isEnd: boolean = false) => {
    const now = new Date();
    let date: Date;

    if (!isEnd) {
      date = new Date(now.getFullYear(), now.getMonth(), 1);
      date.setHours(0, 0, 0, 0);
    } else {
      date = new Date(now.getFullYear(), now.getMonth() + 1, 0);
      date.setHours(23, 59, 59, 999);
    }

    const pad = (n: number) => String(n).padStart(2, "0");
    return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
  };

  const { conta } = useContext(ContaContext);
  const { setMovimentacao } = useContext(MovimentacaoContext);

  // ── estado do formulário de cadastro ──────────────────────────────────────

  const [dataInicial, setDataInicial] = useState(getNow(false));
  const [dataFinal, setDataFinal] = useState(getNow(true));
  const [ocorrencia, setOcorrencia] = useState("1");
  const [mes, setMes] = useState("1");
  const [dia, setDia] = useState("1");
  const [diasSemanaSelecionados, setDiasSemanaSelecionados] = useState<
    number[]
  >([1]);
  const [tipo, setTipo] = useState<string>("receita");
  const [categorias, setCategorias] = useState<CategoriaResponse>();
  const [categoriasSelecionadas, setCategoriasSelecionadas] = useState<
    number[]
  >([]);

  const [titulo, setTitulo] = useState("");
  const [obs, setObservacao] = useState("");

  const [preco, setPreco] = useState<number>(0);
  const [precoFormatado, setPrecoFormatado] = useState<string>("");

  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [erroMsg, setErroMsg] = useState<string>();

  // ── estado da tabela / modal ───────────────────────────────────────────────

  const [fixas, setFixas] = useState<MovimentacaoFixaItem[]>([]);
  const [habilitaEdicao, setHabilitaEdicao] = useState(false);

  const dias = Array.from({ length: diasPorMes[mes] }, (_, i) => ({
    label: String(i + 1),
    value: String(i + 1),
  }));

  // ── busca categorias ──────────────────────────────────────────────────────

  const buscaCategorias = useCallback(async () => {
    try {
      const resposta = await api<CategoriaResponse>(
        `/Contas/${conta!.idConta}/Categorias`,
        "GET",
        undefined,
      );
      if (resposta.sucesso && resposta.dados) {
        setCategorias(resposta.dados);
      }
    } catch (error) {
      console.error("Erro ao buscar categorias:", error);
    }
  }, [conta!.idConta]);

  // ── busca movimentações fixas ─────────────────────────────────────────────

  const buscaFixas = useCallback(async () => {
    try {
      const resposta = await api<{ conteudo: MovimentacaoFixaItem[] }>(
        `/Contas/${conta!.idConta}/Movimentacoes/Fixa`,
        "GET",
        undefined,
      );
      if (resposta.sucesso && resposta.dados) {
        setFixas(resposta.dados.conteudo ?? []);
      }
    } catch (error) {
      console.error("Erro ao buscar fixas:", error);
    }
  }, [conta!.idConta]);

  const CadastraFixas = useCallback(async () => {
    try {
      const resposta = await api<{ conteudo: MovimentacaoFixaItem[] }>(
        `/Contas/${conta!.idConta}/Movimentacoes/Fixa`,
        "GET",
        undefined,
      );
      if (resposta.sucesso && resposta.dados) {
        setFixas(resposta.dados.conteudo ?? []);
      }
    } catch (error) {
      console.error("Erro ao buscar fixas:", error);
    }
  }, [conta!.idConta]);

  useEffect(() => {
    const maxDias = diasPorMes[mes];
    buscaCategorias();
    buscaFixas();

    if (Number(dia) > maxDias) {
      setDia(String(maxDias));
    }
  }, [buscaCategorias, buscaFixas, mes]);

  // ── linha clicada na tabela ───────────────────────────────────────────────

  const handleRowClick = (row: Record<string, any>) => {
    const fixa = row._raw as MovimentacaoFixaItem;
    setOcorrencia(fixa.tipo.toString());
    setDataInicial(fixa.dataInicio);
    setDataFinal(fixa.dataFim);

    setMovimentacao(fixa.movimentacaoBase);
    setHabilitaEdicao(true);
  };

  const diasSemanaMap: Record<number, string> = {
    0: "Domingo",
    1: "Segunda-feira",
    2: "Terça-feira",
    3: "Quarta-feira",
    4: "Quinta-feira",
    5: "Sexta-feira",
    6: "Sábado",
  };
  // ── dados formatados para a tabela ────────────────────────────────────────

  const tabelaDados = fixas.map((f) => ({
    _raw: f,
    titulo: f.movimentacaoBase.titulo,
    tipo: tipoOcorrenciaLabel[f.tipo] ?? f.tipo,
    dataInicio: formatDate(f.dataInicio),
    dataFim: formatDate(f.dataFim),
    dataOcorrencia:
      f.tipo !== 0
        ? f.tipo === 0
          ? ""
          : f.tipo === 1
            ? formatDatemes(f.dataOcorrencia)
            : formatDateAnual(f.dataOcorrencia)
        : f.ocorrenciaDiaria.map((d) => diasSemanaMap[d]).join(", "),

    expirado: f.expirado ? "Sim" : "Não",
  }));

  const tabelaColunas = [
    { header: "Titulo", key: "titulo" },
    { header: "Tipo", key: "tipo" },
    { header: "Início", key: "dataInicio" },
    { header: "Fim", key: "dataFim" },
    { header: "Ocorrência", key: "dataOcorrencia" },
    { header: "Expirado", key: "expirado" },
  ];

  // ── render ────────────────────────────────────────────────────────────────

  const reqMovFixa = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setErroMsg(undefined);

    const toISOString = (data: string) => new Date(data).toISOString();
    const toDateOnly = (data: string) => data.split("T")[0];
    try {
      if (!habilitaEdicao) {
        if (ocorrencia !== "0") {
          const request = {
            tipo: parseInt(ocorrencia),
            dataInicio: toISOString(dataInicial),
            dataFim: toISOString(dataFinal),
            dataOcorrencia: new Date(
              2026,
              Number(mes) - 1,
              Number(dia),
              12,
              0,
              0,
            ).toISOString(),
            movimentacao: {
              tipo: tipo === "receita" ? 0 : 1,
              valor: preco,
              titulo,
              observacao: obs,
              idsCategoria: categoriasSelecionadas,
            },
          };

          console.log(request);
          const resposta = await api<ApiResult<Movimentacao>>(
            `/Contas/${conta?.idConta}/Movimentacoes/Fixa`,
            "POST",
            request,
          );

          if (resposta.sucesso) {
            buscaFixas();
          } else {
            setErroMsg(resposta!.erro || "Erro ao cadastrar movimentação.");
            console.log(resposta!.erro);
          }
        } else {
          const request = {
            dataInicio: toDateOnly(dataInicial),
            dataFim: toDateOnly(dataFinal),
            ocorrenciaDiaria: diasSemanaSelecionados,
            movimentacao: {
              tipo: tipo === "receita" ? 0 : 1,
              valor: preco,
              titulo,
              observacao: obs,
              idsCategoria: categoriasSelecionadas,
            },
          };

          console.log(request);
          const resposta = await api<ApiResult<Movimentacao>>(
            `/Contas/${conta?.idConta}/Movimentacoes/Fixa/Diarias`,
            "POST",
            request,
          );

          if (resposta.sucesso) {
            buscaFixas();
          } else {
            setErroMsg(resposta!.erro || "Erro ao cadastrar movimentação.");
            console.log(resposta!.erro);
          }
        }
      }
    } catch (error: any) {
      setErroMsg(error.message || "Erro inesperado.");
    } finally {
      setIsLoading(false);

      if (erroMsg === undefined) {
        setCategoriasSelecionadas([]);
        setTitulo("");
        setObservacao("");
        setPrecoFormatado("");
        setOcorrencia("1");
        setTipo("receita");
        setDataInicial(getNow(false));
        setDataFinal(getNow(true));
      }
    }
  };

  return (
    <div className="mf-root">
      <TitleText text={`Movimentações Agendadas - ${conta!.titulo}`} />

      {/* ── seção: tabela de fixas cadastradas ── */}
      <section className="mf-section">
        <FncTable
          data={tabelaDados}
          columns={tabelaColunas}
          onRowClick={handleRowClick}
        />
      </section>
      {/* ── seção: configuração da recorrência ── */}
      <section className="mf-section">
        <h2 className="mf-section-title">Recorrência</h2>

        <div className="mf-group">
          <InputSelect
            label="Tipo de Ocorrência"
            opcoes={[
              { label: "Semanal", value: "0" },
              { label: "Mensal", value: "1" },
              { label: "Anual", value: "2" },
            ]}
            value={ocorrencia}
            onChange={setOcorrencia}
          />

          <InputDate
            label="Data Inicial"
            text={dataInicial}
            setText={setDataInicial}
          />

          <InputDate
            label="Data Final"
            text={dataFinal}
            setText={setDataFinal}
          />
        </div>

        {ocorrencia === "0" && (
          <CheckBoxList
            itens={diasSemana}
            idKey="id"
            labelKey="nome"
            selecionados={diasSemanaSelecionados}
            onChange={setDiasSemanaSelecionados}
            label="Dias da Semana"
          />
        )}

        {ocorrencia === "1" && (
          <InputSelect
            label="Dia"
            opcoes={dias}
            value={dia}
            onChange={setDia}
          />
        )}

        {ocorrencia === "2" && (
          <div className="mf-group">
            <InputSelect
              label="Mês"
              opcoes={meses}
              value={mes}
              onChange={setMes}
            />
            <InputSelect
              label="Dia"
              opcoes={dias}
              value={dia}
              onChange={setDia}
            />
          </div>
        )}
      </section>

      {/* ── seção: dados da movimentação ── */}
      <section className="mf-section">
        <h2 className="mf-section-title">Movimentação</h2>

        <div className="fnc-transaction-type">
          <button
            type="button"
            className={`type-btn ${tipo === "receita" ? "active" : ""}`}
            data-type="receita"
            onClick={() => setTipo("receita")}
          >
            Receita
          </button>

          <button
            type="button"
            className={`type-btn ${tipo === "despesa" ? "active" : ""}`}
            data-type="despesa"
            onClick={() => setTipo("despesa")}
          >
            Despesa
          </button>
        </div>

        <div className="mf-group">
          <InputText
            label="Título"
            text={titulo}
            setText={setTitulo}
            placeholder="Ex: Salário"
          />

          <InputPrice
            label="Valor"
            formattedValue={precoFormatado}
            setFormattedValue={setPrecoFormatado}
            setValue={setPreco}
          />
        </div>

        <InputText label="Observação" text={obs} setText={setObservacao} />

        <CheckBoxList<Categoria>
          itens={[...(categorias?.conteudo ?? [])]}
          idKey="idCategoria"
          labelKey="nome"
          selecionados={categoriasSelecionadas}
          onChange={setCategoriasSelecionadas}
          label="Categorias"
        />

        <FncButton title="Cadastrar" onClick={reqMovFixa} />
      </section>

      {/* ── modal de edição ── */}
      <CadContasModal
        isOpen={habilitaEdicao}
        onClose={() => setHabilitaEdicao(false)}
      >
        <CadMov onClose={() => setHabilitaEdicao(false)} edit={true} />
      </CadContasModal>
    </div>
  );
};

export default MovimentacaoFixa;
